<?php

namespace App\Http\Controllers;

use App\Models\TraderUser;
use Illuminate\Http\Request;

class TraderUserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\TraderUser  $traderUser
     * @return \Illuminate\Http\Response
     */
    public function show(TraderUser $traderUser)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\TraderUser  $traderUser
     * @return \Illuminate\Http\Response
     */
    public function edit(TraderUser $traderUser)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\TraderUser  $traderUser
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, TraderUser $traderUser)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\TraderUser  $traderUser
     * @return \Illuminate\Http\Response
     */
    public function destroy(TraderUser $traderUser)
    {
        //
    }
}
